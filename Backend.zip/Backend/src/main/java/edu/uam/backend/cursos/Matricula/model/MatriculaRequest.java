package edu.uam.backend.cursos.Matricula.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class MatriculaRequest {
    private Integer cif;

    private String codigocurso;
}
